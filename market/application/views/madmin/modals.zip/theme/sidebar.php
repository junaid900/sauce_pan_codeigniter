 <?php 
    $cssScriptDir = base_url() . "assets/admin/";
   $system_image = $this->db->get_where('system_settings',array('type'=>'system_image'))->row()->description; ?>
<nav class="navbar-default navbar-static-side" role="navigation">
    <div class="sidebar-collapse">
        <ul class="nav metismenu" id="side-menu">
            <li class="">
                <?php if(!empty($system_image)){ ?>
                <img src="<?php echo base_url(); ?>uploads/admin/<?php echo $system_image; ?>" style="width: 100%;height: 64px;" alt="image">
                <?php }else{ ?>
                <img src="https://via.placeholder.com/70" width="100%" height="64px" alt="">
                <?php } ?>
            </li>
            <li>
                <a href="<?php echo base_url().$this->session->userdata('directory').'/dashboard';?>"><i class="fa fa-home"></i> <span class="nav-label">Home</span></a>
            </li>
            <li>
                <a href="<?php echo base_url().$this->session->userdata('directory').'/orders';?>"><i class="fa fa-align-center"></i> <span class="nav-label">Orders</span></a>
            </li>

            <li class="<?=$main_page_name == "products"?"active":"" ?>">
                <a href="#" class="parent_item"><i class="fa fa-table"></i> <span class="nav-label">Products</span><span class="fa arrow"></span></a>
                <ul class="nav nav-second-level">
                    <li class="<?=$page_name == "manage_category"?"active":"" ?>"><a href="<?=base_url().admin_ctrl(). '/manage_category' ?>">Main Category</a></li>
                    <li class="<?=$page_name == "manage_product_category"?"active":"" ?>"><a href="<?=base_url().admin_ctrl(). '/manage_product_category' ?>">Product Category</a></li>
<!--                    <li><a href="table_data_tables.html">Product Category</a></li>-->
                    <li><a href="table_foo_table.html">Product Attributes</a></li>
                    <li><a href="jq_grid.html">Product Page</a></li>
                </ul>
            </li>

            <li>
                <a href="layouts.html"><i class="fa fa-file-text-o"></i> <span class="nav-label">Coupons</span></a>
            </li>
            <li>
                <a href="#"><i class="fa fa-user-o"></i> <span class="nav-label">Customers</span></a>
            </li>
            <li>
                <a href="#"><i class="fa fa-question-circle-o"></i> <span class="nav-label">Help Center</span></a>
            </li>
            <li>
                <a href="layouts.html"><i class="fa fa-cog"></i> <span class="nav-label">Settings</span></a>
            </li>
        </ul>

    </div>
</nav>
