<?php
	if($this->langtype == '_ch'){
		echo '搜索';
	}else{
		echo 'Search';
	}
?>

<?php if($this->langtype == '_ch'){echo '待办';}else{echo 'Pending';}?>
<?php if($this->langtype == '_ch'){echo '进行中';}else{echo 'In-process';}?>
<?php if($this->langtype == '_ch'){echo '运输';}else{echo 'Shipping';}?>
<?php if($this->langtype == '_ch'){echo '完成';}else{echo 'Complete';}?>
<?php if($this->langtype == '_ch'){echo '打印';}else{echo 'Print';}?>
<?php if($this->langtype == '_ch'){echo '取消';}else{echo 'Cancel';}?>





















