<?php $this->load->view('default/home_header')?>

<a class="login_btn" href="javascript:history.back(-1)" style="margin-top:90px;">
	←  Return
</a>
<div style="width: calc(100% - 20px);padding:0 10px;margin:20px 0;float: left;text-align: left;font-size: 16px;">
	 Refer Saucepan to a friend - receive 50RMB
</div>
<div style="width: calc(100% - 20px);padding:0 10px;margin:20px 0;float: left;text-align: left;font-size: 13px;line-height: 25px;;">
	 How it works:<br>
	 
1 - Share this QR code with your friends, groups, communities<br>
2 - Every new customer ordering through your QR code receives a 50rmb discount<br>
3 - For every order placed through your QR code by a new customer you receive 50rmb worth of loyalty points.<br>

</div>

<div style="width: calc(100% - 40px);padding:50px 20px;float:left;background-color: #f4f4f4;;margin-bottom: 50px;;">
	<img  src="<?php echo base_url().'themes/default/images/qrx_campaign_102.png'?>"  style="width:80%;float:left;margin-left:10%;"/>
</div>









<?php $this->load->view('default/home_footer')?>