</div>
<div class="Frame_Footer">
		<div class="copyright">
			Copyright © <?php echo date('Y')?> All Rights Reserved.
		</div>
	</div>
</body>
</html>