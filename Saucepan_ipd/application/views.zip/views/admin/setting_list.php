<?php $this->load->view('admin/header')?>
<?php $this->load->view('admin/footer')?>