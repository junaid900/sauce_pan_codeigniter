<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="description" content="Sapience Pro is an international financial, human resource and business consulting group with over 20 strategic partners worldwide. ">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
<meta name="keywords" content="HYGENTO">
<link rel="shortcut icon" href="" type="image/x-icon" />
<title>HYGENTO</title>
		
<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>themes/default/base.css?date=<?php echo CACHE_USETIME()?>" />
<script src="<?php echo base_url()?>themes/default/js/jquery-1.11.0.min.js?date=<?php echo CACHE_USETIME()?>"></script>
	
</head>

<body style="<?php if($this->langtype=='_ch'){echo "font-family:Noto;";}else{echo "font-family:Merr;";}?>;">

<div style="position:absolute;top:0px;bottom:0px;left:0px;right:0px;">
	<table cellspacing="0" cellpadding="0" style="float:left;width:100%;height:100%;">
		<tr>
			<td align="center">
				<table cellspacing="0" cellpadding="0">
            		<tr>
            			<td>
                			<a href="<?php echo base_url()?>"><img style="width:180px;" src="<?php echo base_url().'themes/default/images/HYGENTO_logo_smallcolor.png'?>"/></a>
                		</td>
            		</tr>
            	</table>
    			<table cellspacing="0" cellpadding="0" style="margin-top:30px;">
            		<tr>
            			<td>
                			<img src="<?php echo base_url().'themes/default/images/page_404.png'?>"/>
                		</td>
            		</tr>
            	</table>
            	<table cellspacing="0" cellpadding="0" style="color:gray;font-size:20px;margin-top:20px;">
            		<tr>
            			<td>
                			oops! page not found
                		</td>
            		</tr>
            	</table>
            	<table cellspacing="0" cellpadding="0" style="color:gray;font-size:20px;margin-top:20px;">
            		<tr>
            			<td>
                			&nbsp;
                		</td>
            		</tr>
            	</table>
    		</td>
		</tr>
	</table>
	
</div>


</body>
</html>