<?php 
$menu = $this->session->userdata('menu');
$lang = $this->session->userdata('lang');

$get_str='';
if($_GET){
	$arr = geturlparmersGETS();
	for($i=0;$i<count($arr);$i++){
		if(isset($_GET[$arr[$i]])){
			if($get_str!=""){$get_str .='&';}else{$get_str .='?';}
			$get_str .=$arr[$i].'='.$_GET[$arr[$i]];
		}
	}
}
$current_url_encode = str_replace('/','slash_tag',base64_encode(current_url().$get_str));
?>
<div id="mobile_menubg" style="display:none;">
	
</div>
<div id="mobile_menu" style="display:none;">
		<table id="mobile_menutabheight">
				<tr>
					<td class="leftline"></td>
					<td>
						<div class="logobox">
							<span onclick="toreditecturl()"><img alt="GreenGorgeous Logo" title="GreenGorgeous Logo" src="<?php if($this->langtype=='_ch'){echo base_url().'themes/default/images/logo.jpg';}else{echo base_url().'themes/default/images/logo.jpg';}?>"/></span>
						</div>
						<div onclick="tohidetest()" class="closebox">
							<img alt="close menu" title="close menu" src="<?php echo base_url().'themes/default/images/mobile_close_01.png'?>"/>
						</div>
					</td>
				</tr>
				<tr>
					<td class="leftline"></td>
					<td class="contentpadding">
				 		<div class="contentdiv">
				 			<div class="mobileloginboxorinfobox headerviews_checklogin_mo">
		 						
				 			</div>
				 			<div class="nav">
				 			
				 			<div class="mobileloginboxorinfobox">
			 					<a href="<?php echo base_url().'index.php/welcome/#do'?>" class="contentloginuser"><span class="name" style="font-size: 12px;"> <?php 
								if($this->langtype == '_ch'){
									echo '';
								}else{
									echo '';
								}
							?></span></a>
				 			</div>
				 			
				 			
				 			
				 			</div>
				 			<div style="border:2px dashed #555;float:left;width:100%;margin:10px auto;"></div>
				 			<div class="mobileloginboxorinfobox" style="display:none;">
			 					<a href="" class="contentloginuser"><span class="name" style="font-size: 12px;">
			 					 <?php 
								if($this->langtype == '_en'){
									echo 'Language';
								}else if($this->langtype == '_ch'){
									echo '语言';
								}else{
									echo '語言';
								}
							?>
			 					</span></a>
				 			</div>
				 			<div class="mobileloginboxorinfobox" style="display:none;">
			 					<a href="<?php echo base_url().'index.php/welcome/changelanguage/en/'.$current_url_encode?>" class="contentloginuser" style="text-indent:20px;font-size: 12px;"><span class="name" >
			 					  ◆  English
			 					</span></a>
				 			</div>
				 			<div class="mobileloginboxorinfobox" style="display:none;">
			 					<a href="<?php echo base_url().'index.php/welcome/changelanguage/ch/'.$current_url_encode?>" class="contentloginuser" style="text-indent:20px;font-size: 12px;"><span class="name">
			 					   ◆ 简体中文
			 					</span></a>
				 			</div>
				 		</div>
					</td>
				</tr>
			</table>
			
</div>
<div class="header_list_two" style="">
	<div class="subarea">
		<div class="caidanbg"></div>
		<div class="caidan">
			<div class="content">
				<div class="languagearea" >
					<?php if($lang == 'en'){?>
						<a href="<?php echo base_url().'index.php/welcome/changelanguage/ch/'.$current_url_encode?>">中文</a>
					<?php }else{?>
						<a href="<?php echo base_url().'index.php/welcome/changelanguage/en/'.$current_url_encode?>">EN</a>
					<?php }?>
				</div>
				<div id="menu_mobile_logo">
					
					<a href="<?php echo base_url()?>"><img alt="" title="GreenGorgeous Logo" src="<?php if($this->langtype=='_ch'){echo base_url().'themes/default/images/logo.jpg';}else{echo base_url().'themes/default/images/logo.jpg';}?>"/></a>
				</div>
				<?php $setokenphp='';?>
				<div class="rightmenuactionarea" onclick="javascript:location.href='<?php echo base_url().'index.php/welcome/login'?>';">
					<?php if($this->langtype == '_ch'){
							//echo '登录';
						}else{
							//echo 'Login';
						}
						echo '&nbsp;';
					?>
				</div>
				<div class="rightmenuactionarea rightmenuactionareas" onclick="javascript:location.href='<?php echo base_url().'index.php/welcome/account_list'?>';" style="">
					<?php if($this->langtype == '_ch'){
							//echo '顾客';
						}else{
							//echo 'Account';
						}
						echo '&nbsp;';
					?>
				</div>
				
			</div>
		</div>
	</div>
	
</div>
<script>
	// var setoken= getCookie("token");
	// var setoken= getCookie("token");
	// var token_expiry= getCookie("token_expiry");
	// var myDate = new Date();
	// //     var stringTime=myDate.getFullYear()+'-'+(myDate.getMonth()+1)+'-'+myDate.getDate()+' '+'16:39:00'
	// console.log(token_expiry,myDate)
	// var timestamp = new Date(token_expiry).getTime()
	// var timestamp1 = Date.parse(new Date());
	// console.log(timestamp,timestamp1)
	
	// if(timestamp<=timestamp1){
	// 	console.log('头部token已经失效')
	// 	$(".rightmenuactionarea").css("display","block")
	// 	$(".rightmenuactionareas").css("display","none")
	// }else if(timestamp>timestamp1){
	// 	console.log('头部token有效')
	// 	$(".rightmenuactionarea").css("display","none")
	// 	$(".rightmenuactionareas").css("display","block")
	// }else{
	// 	console.log('头部token未知效')
	// 	$(".rightmenuactionarea").css("display","block")
	// 	$(".rightmenuactionareas").css("display","none")
	// }
	$.ajax({
	
	 type: 'POST',
	 url: "<?php echo base_url().'index.php/sessiones/get?token&user&token_expiry'?>",
	 cache:false,
	 dataType: "json", 
	 // data: formData,
	 processData: false,
	 contentType: false, //data: {key:value}, 
	 headers : {'ApiKey':'XXXXXX-XXXXXX-JUnsa1988938922039:012900929'}, 
	 success: function(data){
	    //函数参数 "data" 为请求成功服务端返回的数据
			console.log("哈哈",data,data.token_expiry)  
			var timestamp = data.token_expiry;
			var timestamp1 =  ( new  Date()).valueOf()/1000;
			// console.log(timestamp1)
			if(timestamp==0){
				console.log("无登录状态")
				$(".rightmenuactionarea").css("display","block")
				$(".rightmenuactionareas").css("display","none")
			}
			if(timestamp<=timestamp1){
				console.log('头部token已经失效')
				$(".rightmenuactionarea").css("display","block")
				$(".rightmenuactionareas").css("display","none")
			}else if(timestamp>timestamp1){
				console.log('头部token有效')
				$(".rightmenuactionarea").css("display","none")
				$(".rightmenuactionareas").css("display","block")
			}else{
				console.log('头部token未知效')
				$(".rightmenuactionarea").css("display","block")
				$(".rightmenuactionareas").css("display","none")
			}
			
	},
	});
$(".name").click(function(){

	$('#menu_control_01').show();
	$('#menu_control_02').hide();
	$('#menu_mobile_logo').parent().parent().show();
	$('#mobile_menu, #mobile_menubg').animate({height:"hide"},300,function (data){

	});
})
</script>